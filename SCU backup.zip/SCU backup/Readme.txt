implemented:
*Loopback for RS-232, RS-485, RS422
*wire break detection
*Avg of ADC values with 10 samples
*delimiter at complete data including senser val and time