/*
 * Global.h
 *
 *  Created on: Oct 22, 2024
 *      Author: AEM
 */

#ifndef INC_GLOBAL_H_
#define INC_GLOBAL_H_


#define ADC_MAX_VAL			26500
#define ADC_MIN_VAL 		8188
#define ADCsample  			10
#define Wirebrake  			6
extern uint8_t AdcSensor_Avg(uint16_t,uint8_t );

typedef enum adc_channel
{
	channel_1=1,
	channel_2,
	channel_3,
	channel_4,
}adcchannel;

typedef struct{

	uint16_t channel[ADCsample];
	uint8_t Index;
	uint32_t sum;
	uint16_t average;
	uint8_t count;
}_sADCavgcal;



#endif /* INC_GLOBAL_H_ */
