/*
 * Global.h
 *
 *  Created on: Oct 22, 2024
 *      Author: AEM
 */

#ifndef INC_GLOBAL_H_
#define INC_GLOBAL_H_


#define ADC_MAX_VAL			26500
#define ADC_MIN_VAL 		8188
#define ADCsample  			10
#define Wirebrake  			6
#define SoF					'@'
#define EoF					'$'

extern uint8_t AdcSensor_Avg(uint16_t,uint8_t, uint8_t);

/*
 * This is ADC channels,
 * using in AdcSensor_Avg() function
 */
typedef enum adc_channel
{
	channel_1=1,
	channel_2,
	channel_3,
	channel_4,
}adcchannel;


typedef enum adc
{
	adc_1=1,
	adc_2,
	adc_3,
}adc;

/*
 * structure is using for avg calculation,
 * in AdcSensor_Avg() function
 */
typedef struct{

	uint16_t channel[ADCsample];
	uint8_t Index;
	uint32_t sum;
	uint16_t average;
	uint8_t count;
}_sADCavgcal;


typedef struct{

	_sADCavgcal ADCavgcal_1;
	_sADCavgcal ADCavgcal_2;
	_sADCavgcal ADCavgcal_3;
	_sADCavgcal ADCavgcal_4;

}_sADCmodule;



/*
 * Frame of ADC value
 */
typedef struct{

	char Startbyte;
	char adcbuffer[300];
	char Endbyte;
	size_t dataSize;
}_sADCpacket;


#endif /* INC_GLOBAL_H_ */
