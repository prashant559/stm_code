/*
 * ADC_Operations.h
 *
 *  Created on: Nov 11, 2024
 *      Author: AEM
 */

#ifndef INC_ADC_OPERATIONS_H_
#define INC_ADC_OPERATIONS_H_

#define ADC_MAX_VAL			26214
#define ADC_MIN_VAL 		9175//8192

#endif /* INC_ADC_OPERATIONS_H_ */
